#ifndef FILES_H
#define FILES_H

#include "athletes.h"

// Prototypes des fonctions pour charger et sauvegarder les données
void load_athlete_data(Athlete *athlete);
void save_athlete_data(Athlete *athlete);

#endif // FILES_H
