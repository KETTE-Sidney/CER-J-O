#include <stdio.h>
#include <float.h>
#include <stdlib.h>
#include "athletes.h"
#include "stats.h"

// Structure pour stocker les athlètes et leur temps moyen
typedef struct {
    Athlete *athlete;
    float average_time;
} AthleteAverage;

// Fonction pour afficher les meilleures, pires et moyennes performances d'un athlète pour un événement précis
void best_worst_avg(Athlete *athlete, const char *event) {
    float best = FLT_MAX, worst = FLT_MIN, sum = 0;
    int count = 0;
    
    // Parcourt toutes les performances de l'athlète
    for (int i = 0; i < athlete->performance_count; ++i) {
        // Si l'événement correspond, met à jour les statistiques
        if (strcmp(athlete->performances[i].event, event) == 0) {
            float time = athlete->performances[i].time;
            if (time < best) best = time;
            if (time > worst) worst = time;
            sum += time;
            count++;
        }
    }
    // Affiche les résultats si des performances ont été trouvées
    if (count > 0) {
        printf("Best: %.2f, Worst: %.2f, Average: %.2f\n", best, worst, sum / count);
    } else {
        printf("No performances found for event %s\n", event);
    }
}
// Fonction pour afficher les trois meilleurs athlètes pour un événement spécifique
void top_three_athletes(Athlete athletes[], int athlete_count, const char *event) {
    // Alloue de la mémoire pour stocker les temps moyens des athlètes
    AthleteAverage *averages = (AthleteAverage *)malloc(sizeof(AthleteAverage) * athlete_count);
    int count = 0;
    // Parcourt tous les athlètes
    for (int i = 0; i < athlete_count; ++i) {
        float sum = 0;
        int event_count = 0;
        // Calcule le temps moyen pour l'événement spécifié
        for (int j = 0; j < athletes[i].performance_count; ++j) {
            if (strcmp(athletes[i].performances[j].event, event) == 0) {
                sum += athletes[i].performances[j].time;
                event_count++;
            }
        }
         // Si l'athlète a des performances pour cet événement, stocke la moyenne
        if (event_count > 0) {
            averages[count].athlete = &athletes[i];
            averages[count].average_time = sum / event_count;
            count++;
        }
    }

    // Trie les athlètes par temps moyen croissant
    for (int i = 0; i < count - 1; ++i) {
        for (int j = i + 1; j < count; ++j) {
            if (averages[i].average_time > averages[j].average_time) {
                AthleteAverage temp = averages[i];
                averages[i] = averages[j];
                averages[j] = temp;
            }
        }
    }
    // Affiche les trois meilleurs athlètes
    printf("Top 3 athletes for %s:\n", event);
    for (int i = 0; i < count && i < 3; ++i) {
        printf("%s: %.2f\n", averages[i].athlete->name, averages[i].average_time);
    }
     // Libère la mémoire allouée
    free(averages);
}
// Fonction qui compare performances d'un athlète entre deux dates pour un événement spécifique
void performance_difference(Athlete *athlete, const char *event, const char *date1, const char *date2) {
    float time1 = -1, time2 = -1;
    // Parcourt toutes les performances de l'athlète
    for (int i = 0; i < athlete->performance_count; ++i) {
        // Si l'événement et la date correspondent, enregistre le temps
        if (strcmp(athlete->performances[i].event, event) == 0) {
            if (strcmp(athlete->performances[i].date, date1) == 0) {
                time1 = athlete->performances[i].time;
            }
            if (strcmp(athlete->performances[i].date, date2) == 0) {
                time2 = athlete->performances[i].time;
            }
        }
    }
     // Affiche la différence de performance si les deux dates ont des performances
    if (time1 != -1 && time2 != -1) {
        printf("Difference in performance for %s between %s and %s: %.2f\n", event, date1, date2, time2 - time1);
    } else {
        printf("Performance data not found for the given dates and event.\n");
    }
}
