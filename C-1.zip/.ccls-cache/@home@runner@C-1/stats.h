#ifndef STATS_H
#define STATS_H

#include "athletes.h"

// Prototypes des fonctions pour calculer les statistiques
void best_worst_avg(Athlete *athlete, const char *event);
void top_three_athletes(Athlete athletes[], int athlete_count, const char *event);
void performance_difference(Athlete *athlete, const char *event, const char *date1, const char *date2);

#endif // STATS_H
