#include <stdio.h>
#include <string.h>
#include "events.h"
// Fonction pour initialiser une liste d'événements
void init_events(Event events[], int *event_count) {
    *event_count = 5;
    // Initialise les noms des événements
    strcpy(events[0].name, "100m");
    strcpy(events[1].name, "400m");
    strcpy(events[2].name, "5000m");
    strcpy(events[3].name, "marathon");
    strcpy(events[4].name, "relay");
}
// Fonction pour afficher tous les événements disponibles
void list_events(const Event events[], int event_count) {
    for (int i = 0; i < event_count; ++i) {
        // Affiche le nom de chaque événement
        printf("%s\n", events[i].name);
    }
}
// Fonction pour vérifier si un événement est valide
int is_valid_event(const Event events[], int event_count, const char *event_name) {
    for (int i = 0; i < event_count; ++i) {
         // Retourne 1 si l'événement est trouvé dans la liste
        if (strcmp(events[i].name, event_name) == 0) {
            return 1;
        }
    }
    return 0; // Retourne 0 si l'événement n'est pas trouvé
}
