#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "athletes.h"
#include "file.h"

// Fonction pour ajouter une nouvelle performance à un athlète
void add_performance(Athlete *athlete, Performance performance) {
    // Réalloue la mémoire pour inclure la nouvelle performance
    Performance *new_performances = (Performance *)realloc(athlete->performances, sizeof(Performance) * (athlete->performance_count + 1));
    if (new_performances == NULL) {
        // Affiche un message d'erreur si la réallocation échoue
        fprintf(stderr, "Memory allocation failed\n");
        return;
    }
    athlete->performances = new_performances;
    // Ajoute la nouvelle performance
    athlete->performances[athlete->performance_count] = performance;
    athlete->performance_count++;

    // Sauvegarde les données de l'athlète dans un fichier
    save_athlete_data(athlete);
}

// Fonction pour afficher les détails d'une performance
void display_performance(Performance p) {
    printf(COLOR_BLUE "Date: %s, " COLOR_YELLOW "Event: %s, " COLOR_GREEN "Time: %.2f" COLOR_RESET, p.date, p.event, p.time);
     // Affiche la position du relais si l'événement est un relais
    if (strcmp(p.event, "relay") == 0) {
        printf(COLOR_RED ", Position: %d" COLOR_RESET, p.relay_position);
    }
    printf("\n");
}
// Fonction pour afficher les performances d'un athlète pour un événement spécifique
void view_performances_by_event(Athlete *athlete, const char *event) {
    for (int i = 0; i < athlete->performance_count; ++i) {
        if (strcmp(athlete->performances[i].event, event) == 0) {
            display_performance(athlete->performances[i]);
        }
    }
}
// Fonction pour afficher les performances d'un athlète pour une date spécifique
void view_performances_by_date(Athlete *athlete, const char *date) {
    // Parcourt toutes les performances de l'athlète
    for (int i = 0; i < athlete->performance_count; ++i) {
        if (strcmp(athlete->performances[i].date, date) == 0) {
            display_performance(athlete->performances[i]);
        }
    }
}
// Fonction pour trouver un athlète par son nom
Athlete* find_athlete(Athlete athletes[], int athlete_count, const char *name) {
     // Parcourt toutes les performances de l'athlète
    for (int i = 0; i < athlete_count; ++i) {
         // Retourne l'athlète si le nom correspond
        if (strcmp(athletes[i].name, name) == 0) {
            return &athletes[i];
        }
    }
    return NULL; // Athlete not found
}
