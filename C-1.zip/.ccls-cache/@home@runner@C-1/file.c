#include <stdio.h>
#include <stdlib.h>
#include "athletes.h"
#include "file.h"
// Fonction qui va charger les données d'un athlète depuis un fichier
void load_athlete_data(Athlete *athlete) {
    // Ouvre le fichier en mode lecture
    FILE *file = fopen(athlete->name, "r");
    if (!file) return;
    
    // Lit le nombre de performances
    fscanf(file, "%d", &(athlete->performance_count));
    athlete->performances = (Performance *)malloc(sizeof(Performance) * athlete->performance_count);
    // Lit chaque performance du fichier
    for (int i = 0; i < athlete->performance_count; ++i) {
        fscanf(file, "%s %s %f %d",
               athlete->performances[i].date,
               athlete->performances[i].event,
               &(athlete->performances[i].time),
               &(athlete->performances[i].relay_position));
    }
     // Ferme le fichier
    fclose(file);
}
// Fonction qui va sauvegarder les données d'un athlète dans un fichier
void save_athlete_data(Athlete *athlete) {
    // Ouvre le fichier en mode écriture
    FILE *file = fopen(athlete->name, "w");
    if (!file) return;
    
    // Écrit le nombre de performances dans le fichier
    fprintf(file, "%d\n", athlete->performance_count);
    for (int i = 0; i < athlete->performance_count; ++i) {
        // Écrit chaque performance dans le fichier
        fprintf(file, "%s %s %f %d\n",
                athlete->performances[i].date,
                athlete->performances[i].event,
                athlete->performances[i].time,
                athlete->performances[i].relay_position);
    }
    // Fermeture du fichier
    fclose(file);
}
