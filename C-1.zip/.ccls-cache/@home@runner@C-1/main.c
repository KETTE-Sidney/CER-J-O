#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "athletes.h"
#include "file.h"
#include "stats.h"
#include "events.h"

// Initialisation de coulerus avec ANSI code couleur
#define COLOR_RESET "\x1B[0m"
#define COLOR_RED "\x1B[31m"
#define COLOR_GREEN "\x1B[32m"
#define COLOR_YELLOW "\x1B[33m"
#define COLOR_BLUE "\x1B[34m"

#define MAX_ATHLETES 100

// Fonction pour vérifier s'il s'agit d'une année bissextile
int is_leap_year(int year) {
    return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
}

// Fonction pour valider le format de la date
int validate_date_format(const char *date) {
    if (strlen(date) != 10) return 0; // Vérifie si la longueur est de 10 caractères
    if (date[4] != '-' || date[7] != '-') return 0;// Vérifie les tirets aux positions correctes

    for (int i = 0; i < 10; ++i) {
        if (i == 4 || i == 7) continue;
        if (date[i] < '0' || date[i] > '9') return 0;// Vérifie que les autres caractères sont des chiffres
    }

    int year = atoi(&date[0]);
    int month = atoi(&date[5]);
    int day = atoi(&date[8]);

    if (month < 1 || month > 12) return 0; // Mois valide
    if (day < 1 || day > 31) return 0; // Jour valide

    // Vérification du mois de février
    if (month == 2) { // Février
        if (is_leap_year(year)) {
            if (day > 29) return 0;
        } else {
            if (day > 28) return 0;
        }
    } else if (month == 4 || month == 6 || month == 9 || month == 11) { // Mois de 30 jours
        if (day > 30) return 0;
    }

    return 1;
}

// Fonction pour afficher le menu principal et gérer les interactions de l'utilisateur
void menu(Athlete athletes[], int athlete_count) {
    Performance performance;
    Event events[10];
    int event_count;
    char athlete_name[MAX_NAME_LENGTH];
    char event[MAX_EVENT_LENGTH];
    char date[MAX_DATE_LENGTH];
    char date1[MAX_DATE_LENGTH];
    char date2[MAX_DATE_LENGTH];
    // Initialisation événements
    init_events(events, &event_count);

    int choice;
    do {
        // Affiche le menu
        printf(COLOR_BLUE"\n-"COLOR_YELLOW"-"COLOR_GREEN"-"COLOR_RED"-"COLOR_RESET" Athlete Performance Tracker "COLOR_RED"-"COLOR_GREEN"-"COLOR_YELLOW"-"COLOR_BLUE"-\n" COLOR_RESET);
        printf(COLOR_RED "\n1. Add Performance\n");
        printf(COLOR_BLUE "2. View Performances by Event\n");
        printf("3. View Performances by Date\n");
        printf(COLOR_YELLOW "4. View Statistics\n");
        printf("5. List Events\n");
        printf(COLOR_GREEN "6. Top 3 Athletes for an Event\n");
        printf("7. Performance Difference Between Dates\n");
        printf(COLOR_RED "8. Exit\n" COLOR_RESET);
        printf("Choose an option: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1: {
                // Ajout d'une performance
                printf("Enter athlete's name: ");
                scanf("%s", athlete_name);
                Athlete *athlete = find_athlete(athletes, athlete_count, athlete_name);
                if (!athlete) {
                    printf("Athlete not found.\n");
                    break;
                }
                printf("Enter date (YYYY-MM-DD): ");
                scanf("%s", date);
                if (!validate_date_format(date)) {
                    printf("Invalid date format.\n");
                    break;
                }
                strcpy(performance.date, date);
                printf("Enter event: ");
                scanf("%s", performance.event);
                if (!is_valid_event(events, event_count, performance.event)) {
                    printf("Invalid event. Please choose from the list.\n");
                    list_events(events, event_count);
                    break;
                }
                printf("Enter time: ");
                scanf("%f", &performance.time);
                if (strcmp(performance.event, "relay") == 0) {
                    printf("Enter relay position: ");
                    scanf("%d", &performance.relay_position);
                } else {
                    performance.relay_position = 0;
                }
                add_performance(athlete, performance);
                break;
            }
            case 2: {
                // Affichage des performances par événement
                printf("Enter athlete's name: ");
                scanf("%s", athlete_name);
                Athlete *athlete = find_athlete(athletes, athlete_count, athlete_name);
                if (!athlete) {
                    printf("Athlete not found.\n");
                    break;
                }
                printf("Enter event: ");
                scanf("%s", event);
                if (!is_valid_event(events, event_count, event)) {
                    printf("Invalid event. Please choose from the list.\n");
                    list_events(events, event_count);
                    break;
                }
                view_performances_by_event(athlete, event);
                break;
            }
            case 3: {
                 // Affichage des performances par date
                printf("Enter athlete's name: ");
                scanf("%s", athlete_name);
                Athlete *athlete = find_athlete(athletes, athlete_count, athlete_name);
                if (!athlete) {
                    printf("Athlete not found.\n");
                    break;
                }
                printf("Enter date (YYYY-MM-DD): ");
                scanf("%s", date);
                if (!validate_date_format(date)) {
                    printf("Invalid date format.\n");
                    break;
                }
                view_performances_by_date(athlete, date);
                break;
            }
            case 4: {
                 // Affichage des statistiques
                printf("Enter athlete's name: ");
                scanf("%s", athlete_name);
                Athlete *athlete = find_athlete(athletes, athlete_count, athlete_name);
                if (!athlete) {
                    printf("Athlete not found.\n");
                    break;
                }
                printf("Enter event: ");
                scanf("%s", event);
                if (!is_valid_event(events, event_count, event)) {
                    printf("Invalid event. Please choose from the list.\n");
                    list_events(events, event_count);
                    break;
                }
                best_worst_avg(athlete, event);
                break;
            }
            case 5:
                // Liste tous les événements
                list_events(events, event_count);
                break;
            case 6:
                // Affiche les trois meilleurs athlètes pour un événement spécifique
                printf("Enter event: ");
                scanf("%s", event);
                if (!is_valid_event(events, event_count, event)) {
                    printf("Invalid event. Please choose from the list.\n");
                    list_events(events, event_count);
                    break;
                }
                top_three_athletes(athletes, athlete_count, event);
                break;
            case 7: {
                // Affiche la diff de performance entre deux dates pour un événement
                printf("Enter athlete's name: ");
                scanf("%s", athlete_name);
                Athlete *athlete = find_athlete(athletes, athlete_count, athlete_name);
                if (!athlete) {
                    printf("Athlete not found.\n");
                    break;
                }
                printf("Enter event: ");
                scanf("%s", event);
                if (!is_valid_event(events, event_count, event)) {
                    printf("Invalid event. Please choose from the list.\n");
                    list_events(events, event_count);
                    break;
                }
                printf("Enter first date (YYYY-MM-DD): ");
                scanf("%s", date1);
                if (!validate_date_format(date1)) {
                    printf("Invalid date format.\n");
                    break;
                }
                printf("Enter second date (YYYY-MM-DD): ");
                scanf("%s", date2);
                if (!validate_date_format(date2)) {
                    printf("Invalid date format.\n");
                    break;
                }
                performance_difference(athlete, event, date1, date2);
                break;
            }
            case 8:
                // Quitte le programme
                break;
            default:
                // Gère une option non valide
                printf("Invalid choice. Try again.\n");
        }
    } while (choice != 8);
    // Libère la mémoire allouée pour les performances de chaque athlète

    for (int i = 0; i < athlete_count; ++i) {
        free(athletes[i].performances);
    }
}
// Fonction principale du programme
int main() {
    Athlete athletes[MAX_ATHLETES];
    int athlete_count = 0;
    // Affiche le message de bienvenue
    printf(COLOR_BLUE"\n-"COLOR_YELLOW"-"COLOR_GREEN"-"COLOR_RED"-"COLOR_RESET" Welcome to Athlete Performance Tracker "COLOR_RED"-"COLOR_GREEN"-"COLOR_YELLOW"-"COLOR_BLUE"-\n" COLOR_RESET);
    printf("Enter number of athletes: ");
    scanf("%d", &athlete_count);
    // Saisie des noms des athlètes
    for (int i = 0; i < athlete_count; ++i) {
        printf("Enter athlete's name: ");
        scanf("%s", athletes[i].name);
        athletes[i].performance_count = 0;
        athletes[i].performances = NULL;
        load_athlete_data(&athletes[i]);
    }
    // Affiche le menu pour interagir avec l'utilisateur
    menu(athletes, athlete_count);
    return 0;
    // FIN du programme
}
