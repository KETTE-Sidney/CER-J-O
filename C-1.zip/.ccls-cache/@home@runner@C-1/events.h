#ifndef EVENTS_H
#define EVENTS_H

#define MAX_EVENT_LENGTH 20

// Structure d'un événement
typedef struct {
    char name[MAX_EVENT_LENGTH];
} Event;

// Prototypes des fonctions d'initialisation et de gestion d'évènement
void init_events(Event events[], int *event_count);
void list_events(const Event events[], int event_count);
int is_valid_event(const Event events[], int event_count, const char *event_name);

#endif // EVENTS_H
