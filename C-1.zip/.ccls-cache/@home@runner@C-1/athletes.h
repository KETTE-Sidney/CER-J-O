#ifndef ATHLETES_H
#define ATHLETES_H

#define MAX_NAME_LENGTH 50
#define MAX_DATE_LENGTH 11
#define MAX_EVENT_LENGTH 20

// Initialisation de coulerus avec ANSI code couleur
#define COLOR_RESET "\x1B[0m"
#define COLOR_RED "\x1B[31m"
#define COLOR_GREEN "\x1B[32m"
#define COLOR_YELLOW "\x1B[33m"
#define COLOR_BLUE "\x1B[34m"

typedef struct {
    char date[MAX_DATE_LENGTH];
    char event[MAX_EVENT_LENGTH];
    float time;
    int relay_position; // Utilisé uniquement pour les événements de relais
} Performance;
// structure qui represente un athlète
typedef struct {
    char name[MAX_NAME_LENGTH];
    Performance *performances;
    int performance_count;
} Athlete;

// Prototypes des fonctions
void add_performance(Athlete *athlete, Performance performance);
void display_performance(Performance p);
void view_performances_by_event(Athlete *athlete, const char *event);
void view_performances_by_date(Athlete *athlete, const char *date);
Athlete* find_athlete(Athlete athletes[], int athlete_count, const char *name);

#endif // ATHLETES_H
